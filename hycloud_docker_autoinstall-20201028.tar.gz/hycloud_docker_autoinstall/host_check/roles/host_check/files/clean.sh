#!/bin/bash
rm -f host_listening_ports.txt
rm -f port_check_list.txt
